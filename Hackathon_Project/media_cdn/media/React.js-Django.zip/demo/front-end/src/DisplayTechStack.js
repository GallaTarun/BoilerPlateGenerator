import React, { useEffect, useState} from 'react'

export default function DisplayTechStack() {
    let [techstack, setTechStack] = useState([])

    useEffect(function(){
        fetch('http://localhost:8000/api/techstacks/').then(response => response.json())
            .then(data => setTechStack(data));
    }, [])


  return (
    <div>
        <h3 className="bg-info text-white p-3">Development Project</h3>
        <div>
        <p>This application is created using React as Frontend and Django as Backend</p>
        <p>The following techstack is supported by Skeleton App Generator:</p>
        <table className="table table-bordered table-responsive-xl">
            <thead className='bg-info text-white'>
                <tr>
                    <th>Frontend</th>
                    <th>Backend</th>
                </tr>
            </thead>
            <tbody>
                {techstack.map((item, idx) => <tr key={idx}>
                    <td>{item.frontend}</td>
                    <td>{item.backend}</td>
                </tr>)}
            </tbody>
        </table>
        <p> And many more...</p>
        <p> Please refer to original site</p>
        </div>
    </div>
  )
}
