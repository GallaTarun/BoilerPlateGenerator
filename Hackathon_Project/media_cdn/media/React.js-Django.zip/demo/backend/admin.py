from django.contrib import admin
from .models import Techstack

# Register your models here.
class TechstackAdmin(admin.ModelAdmin):
  list = ('frontend', 'backend')

admin.site.register(Techstack, TechstackAdmin)