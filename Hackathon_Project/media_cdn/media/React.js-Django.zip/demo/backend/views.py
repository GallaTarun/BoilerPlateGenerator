from django.shortcuts import render
from .serializers import TechstackSerializer 
from rest_framework import viewsets      
from .models import Techstack                

class TechstackView(viewsets.ModelViewSet):  
    serializer_class = TechstackSerializer   
    queryset = Techstack.objects.all() 