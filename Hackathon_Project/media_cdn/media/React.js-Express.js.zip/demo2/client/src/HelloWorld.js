import React, { useEffect, useState } from 'react'

export default function HelloWorld() {
    let [message, setMessage] = useState("");

    useEffect(function(){
        fetch("http://localhost:9000/hello").then(response => response.text()).then(data => setMessage(data));
    }, [])
  return (
    <div>
        <h3 className="bg-info p-3">Development Project</h3>
        <div className="p-3 card">
        <p>{message}</p>
        <p>This project is downloaded using Skeleton App Generator</p>
        </div>
    </div>
  )
}
