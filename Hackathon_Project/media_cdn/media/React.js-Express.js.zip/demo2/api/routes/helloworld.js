var express = require('express');
var router = express.Router();

router.get("/", function(req, res, next) {
    res.send("This is a project developed using React as front end and Express as backend");
});

module.exports = router;